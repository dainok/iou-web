<?php
	include('includes/conf.php');
	header("Location: ".BASE_WWW."/laboratories.php");
?>
