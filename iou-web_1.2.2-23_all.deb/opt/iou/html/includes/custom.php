<?php
define('ADMIN', true);
define('CHECK_UPDATE', false);
?>
