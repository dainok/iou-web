// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Alternate style-sheet:": "代替スタイルシート:",
  "Background color:": "背景色:",
  "Cancel": "中止",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "文書のプロパティ",
  "Document title:": "文書の表題:",
  "OK": "OK",
  "Primary style-sheet:": "優先スタイルシート:",
  "Text color:": "文字色:",
  "Character set:": "文字セット:",
  "Description:": "説明:",
  "Keywords:": "キーワード:",
  "UTF-8 (recommended)": "UTF-8 (推奨)"
};