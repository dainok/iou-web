// I18N constants
// LANG: "de", ENCODING: UTF-8 | ISO-8859-1
{
  "Page Cleaner": "Seite bereinigen",
  "Cleaning Area": "Reinigungsbereich",
  "Selection": "Ausgewählter Bereich",
  "All": "Alles",
  "Cleaning options": "Reinigungsoptionen",
  "Formatting:": "Formatierung:",
  "All HTML:": "Ganzes HTML:",
  "Select which types of formatting you would like to remove." : "Wählen Sie aus welche Formatierungen Sie entfernen wollen."
};
