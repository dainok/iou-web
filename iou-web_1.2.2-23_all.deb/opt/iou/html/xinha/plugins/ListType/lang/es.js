// I18N constants
// LANG: "es", ENCODING: UTF-8
// translated: Derick Leony <dleony@gmail.com>
{
  "Decimal numbers": "Números",
  "Lower roman numbers": "Números romanos en minúsculas",
  "Upper roman numbers": "Números romanos en mayúsculas",
  "Lower latin letters": "Letras minúsculas",
  "Upper latin letters": "Letras mayúsculas",
  "Lower greek letters": "Letras griegas minúsculas",
  "Choose list style type (for ordered lists)": "Seleccionar estilo de lista (para listas ordenadas)"
};
