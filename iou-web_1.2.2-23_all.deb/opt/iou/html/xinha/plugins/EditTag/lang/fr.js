// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Edit HTML for selected text": "Editer le code HTML du texte sélectionné",
  "Tag Editor": "Editeur de tag HTML"
};