// I18N constants
// LANG: "de", ENCODING: UTF-8
{ 
	"Insert Snippet": "Snippet einfügen",
	"Cancel": "Abbrechen",
	"Variable":"Variable",
	"Insert as":"Einfügen als",
	"Show preview":"Vorschau zeigen",
	"Hide preview":"Vorschau verbergen"
};