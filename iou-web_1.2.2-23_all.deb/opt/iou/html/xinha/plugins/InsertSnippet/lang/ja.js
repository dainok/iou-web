// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
	"Insert Snippet": "スニペットの挿入",
	"Cancel": "中止",
	"Variable":"変数",
	"Insert as":"形式を選んで挿入",
	"Show preview":"プレビュー表示",
	"Hide preview":"プレビュー非表示"
};