// I18N constants
// LANG: "es", ENCODING: UTF-8
{
  "You have unsaved changes in the editor": "Usted no ha guardado sus modificaciones"
};
