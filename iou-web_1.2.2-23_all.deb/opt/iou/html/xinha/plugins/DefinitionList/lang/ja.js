// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "definition list": "定義リスト",
  "definition term": "定義語",
  "definition description": "定義の説明"
}