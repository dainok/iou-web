// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Set Id and Name": "Sett ID og navn",
  "Name/Id": "Navn (ID)",
  "Delete": "Slett"
};
