// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
	"SmartReplace Settings" : "Paramètres SmartReplace",
	"Enable automatic replacements" : "Activer le remplacement automatique",
	"Convert all quotes and dashes in the current document": "Convertir tous les guillemets et tirets dans le document actuel",

	"OpeningDoubleQuotes": "»",
	"ClosingDoubleQuotes": "«",
	"OpeningSingleQuote": "",
	"ClosingSingleQuote": ""

};