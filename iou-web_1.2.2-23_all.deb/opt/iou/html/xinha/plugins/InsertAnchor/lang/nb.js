// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Insert Anchor": "Sett inn anker",
  "Anchor name": "Ankernavn (ID)"
};