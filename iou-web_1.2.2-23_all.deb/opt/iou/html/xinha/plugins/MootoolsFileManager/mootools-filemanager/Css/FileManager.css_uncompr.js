div.filemanager-container { display: none; }
div.filemanager * { outline: 0; }
div.filemanager a img { border: 0 }

div.filemanager-container, div.filemanager, div.filemanager button, div.filemanager label, div.filemanager h1 {
	width: auto;
	margin: 0;
	
	font-family: Tahoma, sans-serif;
	font-size: 12px;
	font-weight: normal;
	text-transform: none;
	letter-spacing: 0;
}

div.filemanager {
	background: #eee;
	
	position: absolute;
	z-index: 1001;
	width: 800px;
	height: 450px;

	box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
	-moz-box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
}

div.filemanager div.filemanager-menu {
	position: absolute;
	height: 30px;
	left: 30%;
	width: 70%;
	bottom: 0;
	line-height: 30px;
	
	border-top: 1px solid #bebebe;
	background: url(../Assets/menu.png) repeat-x;
}

div.filemanager button {
	cursor: pointer;
	height: 22px;
	line-height: 22px;
	margin: 4px 5px;
	padding: 0 2px;
	
	color: #333;
	text-shadow: #eee 1px 1px 1px;
	
	clear: none;
	background: url(../Assets/button.png) repeat-x;
	border: 1px solid #a1aeb9;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
}
div.filemanager-engine-trident4 button, div.filemanager-engine-trident5 button {
	padding: 0 .25em;
	overflow: visible;
}

div.filemanager-menu button {
	float: right;
}

div.filemanager button:hover, div.filemanager button.hover, div.filemanager button:focus {
	border: 1px solid #5f676e;
}

div.filemanager button.disabled, div.filemanager button.disabled:hover, div.filemanager button.disabled:focus {
	cursor: default;
	color: #666;
	text-shadow: none;
	background: url(../Assets/button_disabled.png) repeat-x;
	border-color: #bababa;
}

div.filemanager button.filemanager-open {
	font-weight: bold;
}

div.filemanager-menu label {
	cursor: pointer;
	float: right;
	width: auto;
	height: auto;
	line-height: 30px;

	font-size: 11px;
}

div.filemanager-menu div.loader {
	float: left;
	width: 16px;
	height: 16px;
	margin: 8px 0;
	background: url(../Assets/loader.gif) no-repeat;
}

div.filemanager ul {
	margin: 0;
	padding: 0;
	position: relative;
	line-height: 1.8em;
	overflow: auto;
	overflow-x: hidden;
	zoom: 1;
}

div.filemanager ul li {
	background: none;
	list-style-image: none;
	list-style-type: none;
	list-style: none;
	line-height: 1.8em;
	margin: 0;
	padding: 0;
	height: 21px;
	white-space: nowrap;
}

div.filemanager ul.filemanager-browser {
	left: 0px;
	top: 0px;
	height: 100%;
	width: 30%;
	
	border: 0;
	border-right: 1px solid #bebebe;
	background: url(../Assets/filelist.png) repeat-x #c1c7cf;
}

div.filemanager-container span.fi {
	height: 21px;
	line-height: 1.8em;
	padding-left: 5px;
	color: #000;
	text-decoration: none;
	display: block;
	white-space: nowrap;
	cursor: pointer;
}

div.filemanager-container span.fi span {
	white-space: nowrap;
	display: block;
	width: 65%;
	overflow: hidden;
}

div.filemanager-container span.drag span, div.filemanager-engine-trident4 ul li span.fi span, div.filemanager-engine-trident5 ul li span.fi span, div.filemanager-engine-presto ul li span.fi span, div.filemanager ul li:hover span.fi span {
	overflow: hidden;
}

div.filemanager ul li span.dir {
	background-color: transparent;
}

div.filemanager ul li span.droppable {
	background-color: #99b7e7;
}

ul.filemanager-browser a, ul.filemanager-browser span {
	position: relative;
}

div.filemanager ul li a.selected, div.filemanager ul li span.selected {
	background: url(../Assets/filelist_selected.png) repeat-x;
	color: #eee;
	outline: none;
}

div.filemanager-container span.fi img {
	display: block;
	float: left;
	margin: 3px 3px 0 0;
}

div.filemanager-container span.fi img.browser-icon {
	float: right;
}

div.filemanager-container span.move img.browser-icon {
	display: none;
}

div.filemanager span.notice {
	position: absolute;
	bottom: 16px;
	left: 16px;
}

div.filemanager div.filemanager-close {
	position: absolute;
	right: -10px;
	top: -10px;
	height: 20px;
	width: 20px;
	
	cursor: pointer;
	background: url(../Assets/button.png) repeat-x;
	border: 1px solid #a1aeb9;
	-moz-border-radius: 10px;
	-webkit-border-radius: 10px;
	border-radius: 10px;
}
div.filemanager div.filemanager-close img {
	padding: 2px;
}

div.filemanager-infos {
	position: absolute;
	left: 30%;
	top: 0;
	width: 70%;
	line-height: 1.6em;
	overflow: auto;
}

div.filemanager-head {
	height: 32px;
	overflow: hidden;
}

img.filemanager-icon {
	float: left;
	margin: 10px 12px;
}

div.filemanager h1 {
	margin: 0;
	padding: 0;
	width: 80%;
	height: 32px;
	line-height: 32px;
	
	color: #333;
	font-size: 20px;
	letter-spacing: 1px;
	overflow: hidden;
	white-space: nowrap;
	background-color: transparent;
}

div.filemanager h2 {
	margin: 0;
	border-top: 1px solid #bebebe;
	font-size: 14px;
	font-weight: bold;
	padding: 2px 0 0 5px;
	clear: both;
}

div.filemanager dl {
	margin: 5px 0;
	width: 100%;
	clear: both;
	overflow: auto;
}

div.filemanager dt, div.filemanager dd {
	float: left;
	line-height: 20px;
	font-size: 11px;
}

div.filemanager dt {
	clear: both;
	width: 22%;
	margin-left: 5%;
	font-weight: bold;
}

div.filemanager dd {
	width: 60%;
	white-space: nowrap;
	overflow: auto;
}

div.filemanager div.margin {
	margin-left: 15px;
}

div.filemanager dd.filemanager-dir a.icon {
	border: 1px solid #bebebe;
	padding: 2px 5px 2px 20px;
	text-decoration: none;
	background: #eee url(../Assets/Icons/dir.png) 2px 0 no-repeat;
	color: #000;

	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}

div.filemanager dd.filemanager-dir a.icon:hover {
	text-decoration: none;
	background-color: #fff;
}

div.filemanager dd.filemanager-dir a.selected, div.filemanager dd.filemanager-dir a.selected:hover {
	margin: 0 1px;
	background-color: transparent;
	border: none;
	cursor: auto;
}

div.filemanager-preview {
	margin-top: 5px;
}

div.filemanager-preview img.preview {
	margin: 0 auto 1em;
	display: block;
	max-height: 100px;
	background: transparent;
}

div.filemanager-engine-trident4 div.filemanager-preview img.preview {
	height: 100px;
}

div.filemanager-preview ul, div.filemanager-uploader ul, div.filemanager-preview div.textpreview {
	border: 1px solid #bebebe;
	background: #fff;
	
	padding: 2px;
	margin: 1em auto;
	
	width: 490px;
	height: 220px;
	overflow: auto;
}

div.filemanager-preview div.textpreview {
	font: 9px Verdana, Arial, Helvetica, sans-serif;
}

div.filemanager-preview div.object {
	width: 200px;
	height: 20px;
	border: 1px solid #bebebe;
	margin: 0 0 1em 190px;
	overflow: hidden;
}

div.filemanager-container img.browser-add {
	position: absolute;
	width: 16px;
	height: 16px;
	z-index: 1010;
}
/* UPLOAD */

div.filemanager-container .file span {
	padding: 0 5px 0 0;
}

div.filemanager-container .file .file-size {
	color: #666;
}

div.filemanager-container .file .file-cancel {
	cursor: pointer;
	padding-left: 5px;
	float: right;
}
div.filemanager-container .file .file-progress {
	margin-top: 5px;
	float: right;
	width: 125px;
	height: 12px;
	background-image: url(../Assets/progress.gif);
}

div.filemanager div.checkbox {
	float: left;
	height: 12px;
	width: 16px;
	margin: 10px 3px 0;
	background: url(../Assets/checkbox.png) no-repeat;
}

div.filemanager div.checkboxChecked {
	background-position: 0 -12px;
}

/* SELECTED FILE */
div.selected-file img {
	vertical-align: bottom;
	padding: 0 3px 0 0;
}
div.selected-file span {
	line-height: 16px;
}
div.selected-file .file-cancel {
	cursor: pointer;
	padding: 0 0 0 5px;
}


/* GALLERY */
div.filemanager button.filemanager-serialize {
	font-weight: bold;
}

div.filemanager-gallery {
	position: absolute;
	z-index: 1000;
	width: 750px;
	height: 144px;
	display: none;

	font-family: Tahoma, sans-serif;
	font-size: 12px;

	border: 1px solid #bebebe;
	border-top: 0;
	background: #eee;

	border-radius-bottomleft: 5px;
	-moz-border-radius-bottomleft: 5px;
	-webkit-border-radius-bottomleft: 5px;

	border-radius-bottomright: 5px;
	-moz-border-radius-bottomright: 5px;
	-webkit-border-radius-bottomright: 5px;
	
	box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
	-moz-box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 0 40px;
}

div.filemanager-gallery div.howto {
	position: absolute;
	z-index: 1002;
	left: 50px;
	top: 60px;
	
	color: #666;
	font-size: 18px;
	font-style: italic;
}

div.filemanager-gallery ul {
	height: 121px;

	margin: 7px 6px;
	padding: 4px;

	overflow: auto;
	overflow-x: hidden;
	border: 1px solid #bebebe;
	background: #f2f2f2;
}

div.filemanager-gallery ul.droppable {
	background-color: #99b7e7;
}

div.filemanager-gallery ul li {
	position: relative;
	float: left;
	margin: 0;
	width: 79px;
	height: 60px;

	list-style: none;
	
	background: url(../Assets/loader.gif) center center no-repeat;
}

div.filemanager-gallery ul li img {
	padding: 2px;
	width: 75px;
	height: 56px;
	cursor: pointer;
}

div.filemanager-gallery ul li img.filemanager-remove {
	position: absolute;
	right: -7px;
	top: -7px;
	width: 16px;
	height: 16px;
}

div.filemanager-wrapper {
	position: absolute;
	z-index: 1020;
	width: 222px;
	height: 250px;

	font-family: Tahoma, sans-serif;
	font-size: 12px;
	
	border: 1px solid #bebebe;
	background: #eee;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
}

div.filemanager-wrapper div.img {
	width: 210px;
	height: 160px;
	margin: 5px;

	border: 1px solid #bebebe;
	background: #fff;
}

div.filemanager-wrapper span {
	display: block;
	margin: 3px 8px 1px;
	font-weight: bold;
}

div.filemanager-wrapper input {
	width: 210px;
	margin: 3px 5px 0;

	border: 1px solid #bebebe;
	background: #fff;
}

div.filemanager-wrapper button {
	margin: 3px 7px;
}

img.filemanager-clone {
	cursor: pointer;
}

/* TIPS */
.tip-filebrowser {
	z-index: 1201;
}
.tip-filebrowser .tip {
	background: #000;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
	border-radius: 5px;
}

.tip-filebrowser .tip-title {
	color: #fff;
	font-size: 11px;
	padding: 1px 4px;
	line-height: 21px;
	text-align: center;
	font-weight: bold;
}

.tip-filebrowser .tip-text {
	display: none;
}
