// I18N constants
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz, http://www.eskot.krakow.pl/portfolio/, koto@webworkers.pl
{
  "You must select some text before making a new link.": "Zaznacz tekst przed dodaniem odnośnika.",
  "Are you sure you wish to remove this link?": "Na pewno chcesz usunąć odnośnik?",
  "Remove Link": "USUŃ ODNOŚNIK",
  "URL Link": "Adres URL",
  "Ordinary Link": "Zwykły odnośnik",
  "Same Window (jump out of frames)": "To samo okno (wyskocz z ramek)",
  "New Window": "Nowe okno",
  "Popup Window": "Okienko pop-up",
  "Email Link": "Link do e-maila",
  "Email Address:": "Adres e-mail",
  "Subject:": "Temat:",
  "Message Template:": "Szablon wiadmości:",
  "Size:": "Rozmiar:",
  "Name:": "Nazwa:"
};